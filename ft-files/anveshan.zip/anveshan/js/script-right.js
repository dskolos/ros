(function ($) {
  
  $.jvmobilemenu({
    mainContent: $('.page'),
    theMenu: $('.mobile-nav'),
    slideSpeed: 0.3,
    menuWidth: 240,
    position: 'right',
    menuPadding: '20px 20px 60px'
  });
  
})(jQuery);